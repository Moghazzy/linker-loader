import pickle
from math import floor
from tkinter import *

top = Tk()
top.title("linker loader")
top.minsize(600, 600)

myLable1 = Label(font=20, text="Enter the address where the program has to be loaded in hex:")
myLable1.pack()
myEntry1 = Entry(borderwidth=4, font=18)
myEntry1.pack()
myLable2 = Label(font=20, text="IF sec write sec - IF secxe write secxe ")
myLable2.pack()
myEntry2 = Entry(borderwidth=4, font=18)
myEntry2.pack()


def on_click():
    class Opcode:
        def __init__(self, code, add):
            self.code = code
            self.add = add
    op = []
    val = int(myEntry1.get(), 16)
    ln = 0
    with open("INPUT.TXT") as INPUT:
        inp = [line.split() for line in INPUT]
    estable = open("ESTAB.TXT", "w")
    estable.close()
    estable = open("ESTAB.txt", "a")
    for i in range(0, len(inp)):
        for j in range(0, len(inp[i])):
            if inp[i][j] == "H":
                    estable.write(inp[i][j + 1] + " " + str(hex(int(inp[i][j + 2], 16) + val+ln)).upper().split("0X")[-1] + " " + str(hex(int(inp[i][j + 3], 16))).upper().split("0X")[-1] + '\n')
                    m = ln
                    ln += int(inp[i][j + 3], 16)
            if inp[i][j] == "D":
                if len(inp[i]) == 3:
                     estable.write("**" + " " + inp[i][j + 1] + " " + str(hex(int(inp[i][j + 2], 16) + val+m)).upper().split("0X")[-1] + '\n')
                if len(inp[i]) == 5:
                    estable.write("**" + " " + inp[i][j + 1] + " " + str(hex(int(inp[i][j + 2], 16) + val+m)).upper().split("0X")[-1] + '\n')
                    j += 2
                    estable.write("**" + " " + inp[i][j + 1] + " " + str(hex(int(inp[i][j + 2], 16) + val+m)).upper().split("0X")[-1] + '\n')

                if len(inp[i]) == 7:
                    estable.write("**" + " " + inp[i][j + 1] + " " + str(hex(int(inp[i][j + 2], 16) + val+m)).upper().split("0X")[-1] + '\n')
                    j += 2
                    estable.write("**" + " " + inp[i][j + 1] + " " + str(hex(int(inp[i][j + 2], 16) + val+m)).upper().split("0X")[-1] + '\n')
                    j += 2
                    estable.write("**" + " " + inp[i][j + 1] + " " + str(hex(int(inp[i][j + 2], 16) + val+m)).upper().split("0X")[-1] + '\n')
                if len(inp[i]) == 9:
                    estable.write("**" + " " + inp[i][j + 1] + " " + str(hex(int(inp[i][j + 2], 16) + val+m)).upper().split("0X")[-1] + '\n')
                    j += 2
                    estable.write("**" + " " + inp[i][j + 1] + " " + str(hex(int(inp[i][j + 2], 16) + val+m)).upper().split("0X")[-1] + '\n')
                    j += 2
                    estable.write("**" + " " + inp[i][j + 1] + " " + str(hex(int(inp[i][j + 2], 16) + val+m)).upper().split("0X")[-1] + '\n')
                    j += 2
                    estable.write("**" + " " + inp[i][j + 1] + " " + str(hex(int(inp[i][j + 2], 16) + val+m)).upper().split("0X")[-1] + '\n')
                m = ln

    estable.close()
    with open("ESTAB.TXT") as ESTAB:
        est = [line.split() for line in ESTAB]
    sections = []
    for i in range(0, len(est)):
        if est[i][0] != "**":
            sections.append(int(est[i][1], 16))
    sections.append(99999999)
    exeloc = int(est[0][1], 16)
    loc = exeloc
    start = loc
    pstart = 0
    mloc = []
    mlen = []
    label = []
    f = 0
    t = 0
    for i in range(0, len(inp)):
        j = 0
        i=t
        if inp[i][j] == "H":
            if j < len(inp[i])-1:
                j += 1
            elif i < len(inp)-1:
                i += 1
                j = 0
            for d in range(0, len(est)):
                if inp[i][j] == est[d][0]:
                    pstart=int(est[d][1], 16)
                    break
            while inp[i][j] != "T":
                if j < len(inp[i])-1:
                    j += 1
                elif i < len(inp)-2:
                    i += 1
                    j = 0
        while True:
            if inp[i][j] == "T":
                if j < len(inp[i])-1:
                    j += 1
                elif i < len(inp)-2:
                    i += 1
                    j = 0
                textloc = int(inp[i][j], 16)
                textloc = textloc + pstart
                for s in range(0, textloc-loc):
                    op.append(Opcode("__", start))
                    start += 1
                if j < len(inp[i])-1:
                    j += 1
                elif i < len(inp)-2:
                    i += 1
                    j = 0
                textlen = int(inp[i][j], 16)
                loc = textloc + textlen
            elif inp[i][j] == "M":
                if j < len(inp[i])-1:
                    j += 1
                elif i < len(inp)-2:
                    i += 1
                    j = 0
                mloc.append(int(inp[i][j], 16)+pstart)
                if j < len(inp[i])-1:
                    j += 1
                elif i < len(inp)-2:
                    i += 1
                    j = 0
                mlen.append(int(inp[i][j], 16))
                if j < len(inp[i])-1:
                    j += 1
                elif i < len(inp)-2:
                    i += 1
                    j = 0
                label.append(inp[i][j])

            else:
                q = 0
                w = 2
                for z in range(0, int(len(inp[i][j])/2.0)):
                    p = inp[i][j][q:w]
                    op.append(Opcode(p, start))
                    q += 2
                    w += 2
                    start += 1
            if j < len(inp[i]) - 1:
                j += 1
            elif i < len(inp) - 1:
                i += 1
                j = 0
            if inp[i][j] == "E":
                i += 1
                j = 0
                break

        if inp[i][j] == "END":
            break
        t = i
    num = 0
    for i in range(0, len(mloc)):
        for j in range(0, len(op)):
            if mloc[i] == op[j].add:
                break
        if str(op[j].code) == '__':
            op[j].code = "00"
            op[j+1].code = "00"
            op[j+2].code = "00"
        s=int(str(op[j].code)+str(op[j+1].code)+str(op[j+2].code), 16)
        for k in range(0, len(est)):
            for r in range(0, len(est[k])):
                if est[k][r] == label[i][1:]:
                    num = int(est[k][r+1], 16)
                    break
        if label[i][0] == '+':
            sum = s+num
            sumstr = (hex(sum)).upper().split("0X")[-1]
            while len(sumstr) < 6:
                sumstr = '0' + sumstr
            q = 0
            w = 2
            for z in range(0, 3):
                p = sumstr[q:w]
                op[j].code = p
                q += 2
                w += 2
                j += 1
            if label[i][0] == '-':
                sum = s-num
                sumstr = (hex(sum)).upper().split("0X")[-1]
                while len(sumstr) < 6:
                    sumstr = '0'+sumstr
                q = 0
                w = 2
                for z in range(0, 3):
                    p = sumstr[q:w]
                    op[j].code = p
                    q += 2
                    w += 2
                    j += 1

    y1 = 0
    y2 = 0
    s = str(hex(op[0].add)).upper().split("0X")[-1] + "\t"
    for h in range(0, len(op)):
        for k in range(0, len(sections)):
            if op[h].add > sections[k] and op[h].add <sections[k + 1]:
                s += op[h].code
                break
        y1 += 1


        if y1 >= 4:
            s += "\t"
            y1 = 0
            y2 += 15
        if y2 >= 4:
            s += "\n"+str(hex(op[h].add+1)).upper().split("0X")[-1]+"\t"
            y2 = 0

    finallabel = Label(text=s, font=18)
    finallabel.pack()

    final = open("OUTPUT.TXT", "w")
    final.write(s)
    estable.close()






btn = Button(text="locate", command=on_click)
btn.pack()

top.mainloop()
